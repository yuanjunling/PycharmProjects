This will work only if the library is already installed on the current machine.
Docs created with the following commandline:

python -m robot.libdoc -f HTML MongoDBLibrary MongoDBLibrary.html


