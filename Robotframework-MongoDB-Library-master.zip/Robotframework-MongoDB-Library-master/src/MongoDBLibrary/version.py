# Update this before release
VERSION = "0.4"
