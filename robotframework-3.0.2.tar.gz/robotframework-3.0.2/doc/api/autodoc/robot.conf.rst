robot.conf package
==================

.. automodule:: robot.conf
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

robot.conf.gatherfailed module
------------------------------

.. automodule:: robot.conf.gatherfailed
    :members:
    :undoc-members:
    :show-inheritance:

robot.conf.settings module
--------------------------

.. automodule:: robot.conf.settings
    :members:
    :undoc-members:
    :show-inheritance:


