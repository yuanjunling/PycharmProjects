def get_variables(name='MY_VAR', value='MY_VALUE'):
    return {name: value}
