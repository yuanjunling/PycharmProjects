def get_variables(name, value):
    return {name: value}
