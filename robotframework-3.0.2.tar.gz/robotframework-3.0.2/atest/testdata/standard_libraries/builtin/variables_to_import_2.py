def get_variables(arg1, arg2='default'):
    return {'IMPORT_VARIABLES_2': 'Dynamic variable file',
            'IMPORT_VARIABLES_2_ARGS': '%s %s' % (arg1, arg2),
            'COMMON VARIABLE': 2}
