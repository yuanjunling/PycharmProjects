class ExampleObject(object):
    def __init__(self, name='<noname>'):
        self.name = name


OBJ = ExampleObject('dude')
