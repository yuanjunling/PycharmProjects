__all__ = ['variables', 'LIST__valid_list']

variables = 'Variable from variables.py'
LIST__valid_list = 'This is a list'.split()
not_included = 'Non in __all__ and thus not incuded'

