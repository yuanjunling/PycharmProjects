def keyword_in_mylibdir_subpackage2_package():
    pass
