def keyword_in_my_lib_file():
    print('Here we go!!')

def embedded(arg):
    print(arg)

embedded.robot_name = 'Keyword with embedded ${arg} in MyLibFile'
