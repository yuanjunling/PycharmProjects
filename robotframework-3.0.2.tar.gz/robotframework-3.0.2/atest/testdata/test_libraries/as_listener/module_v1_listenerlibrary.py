class Listener(object):

    def close(self):
        pass

class Listener2(object):

    def close(self):
        pass


ROBOT_LIBRARY_LISTENER = [Listener(), Listener2()]
