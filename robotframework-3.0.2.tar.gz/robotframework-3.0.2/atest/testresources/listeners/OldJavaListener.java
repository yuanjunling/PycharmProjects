import java.io.IOException;

public class OldJavaListener {

    public OldJavaListener() throws IOException {
    }

    public void close() throws IOException {
    }
}
