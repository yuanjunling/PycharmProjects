

public class Extended extends ArgumentTypes {

    public int handler_count = super.handler_count + 1;

    public void my_own_handler() {
    }

}
