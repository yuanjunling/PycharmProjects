package org.robotframework;

public class JarLib {
	
	public void kwFromJar(String arg) {
		System.out.println("*INFO*" + arg);
	}
}
