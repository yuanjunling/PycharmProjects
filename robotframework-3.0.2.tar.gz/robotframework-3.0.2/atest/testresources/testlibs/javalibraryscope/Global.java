package javalibraryscope;

public class Global extends BaseLib{
	
	public static String ROBOT_LIBRARY_SCOPE = "GLOBAL"; 
	
}