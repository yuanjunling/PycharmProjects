public class FatalCatastrophyException extends RuntimeException {
    public static final boolean ROBOT_EXIT_ON_FAILURE = true;
}